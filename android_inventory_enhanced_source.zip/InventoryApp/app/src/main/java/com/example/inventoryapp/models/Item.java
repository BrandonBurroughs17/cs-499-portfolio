package com.example.inventoryapp.models;

public class Item {
    public int id;
    public String name;
    public int quantity;

    public Item(int id, String name, int quantity) {
        this.id = id;
        this.name = name;
        this.quantity = quantity;
    }
}