package com.example.inventoryapp.activities;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.inventoryapp.database.DatabaseHelper;
import com.example.inventoryapp.R;

public class LoginActivity extends AppCompatActivity {

    EditText user, pass;
    Button loginBtn, createBtn;
    DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        db = new DatabaseHelper(this);

        user = findViewById(R.id.username);
        pass = findViewById(R.id.password);
        loginBtn = findViewById(R.id.loginBtn);
        createBtn = findViewById(R.id.createBtn);

        // Log in to an existing account.
        loginBtn.setOnClickListener(v -> {

            String username = user.getText().toString().trim();
            String password = pass.getText().toString();

            // Prevent empty credentials.
            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(
                        this,
                        "Username and password are required",
                        Toast.LENGTH_SHORT
                ).show();

                return;
            }

            // Account must already exist to log in.
            if (!db.userExists(username)) {
                Toast.makeText(
                        this,
                        "Account does not exist",
                        Toast.LENGTH_SHORT
                ).show();

                return;
            }

            if (db.validateUser(username, password)) {
                startActivity(
                        new Intent(this, MainActivity.class)
                );
            } else {
                Toast.makeText(
                        this,
                        "Invalid username or password",
                        Toast.LENGTH_SHORT
                ).show();
            }
        });

        // Create a new account.
        createBtn.setOnClickListener(v -> {

            String username = user.getText().toString().trim();
            String password = pass.getText().toString();

            // Prevent empty accounts.
            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(
                        this,
                        "Username and password are required",
                        Toast.LENGTH_SHORT
                ).show();

                return;
            }

            // Prevent duplicate usernames.
            if (db.userExists(username)) {
                Toast.makeText(
                        this,
                        "Account already exists",
                        Toast.LENGTH_SHORT
                ).show();

                return;
            }

            db.insertUser(username, password);

            Toast.makeText(
                    this,
                    "Account created successfully",
                    Toast.LENGTH_SHORT
            ).show();
        });
    }
}