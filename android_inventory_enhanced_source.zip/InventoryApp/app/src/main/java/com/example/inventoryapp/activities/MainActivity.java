package com.example.inventoryapp.activities;

import android.Manifest;
import android.database.Cursor;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.example.inventoryapp.database.DatabaseHelper;
import com.example.inventoryapp.models.Item;
import com.example.inventoryapp.adapters.ItemAdapter;
import com.example.inventoryapp.R;

public class MainActivity extends AppCompatActivity {

    private static final int LOW_STOCK_THRESHOLD = 5;

    DatabaseHelper db;

    // Stores all items returned by the current database query.
    List<Item> allItems = new ArrayList<>();

    // Stores the items currently displayed in the RecyclerView.
    List<Item> list = new ArrayList<>();

    ItemAdapter adapter;

    EditText name, qty, searchInput;
    Spinner sortSpinner;
    CheckBox lowStockCheckBox;
    RecyclerView rv;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_inventory);

        // Initialize database
        db = new DatabaseHelper(this);

        // Link UI elements
        name = findViewById(R.id.nameInput);
        qty = findViewById(R.id.qtyInput);
        searchInput = findViewById(R.id.searchInput);
        sortSpinner = findViewById(R.id.sortSpinner);
        lowStockCheckBox = findViewById(R.id.lowStockCheckBox);
        rv = findViewById(R.id.recyclerView);

        // Setup RecyclerView
        rv.setLayoutManager(new LinearLayoutManager(this));
        adapter = new ItemAdapter(list);
        rv.setAdapter(adapter);

        // Setup sorting options
        String[] sortOptions = {
                "Name: A to Z",
                "Name: Z to A",
                "Quantity: Low to High",
                "Quantity: High to Low"
        };

        ArrayAdapter<String> sortAdapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_item,
                sortOptions
        );

        sortAdapter.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item
        );

        sortSpinner.setAdapter(sortAdapter);

        // Sort the currently displayed collection
        sortSpinner.setOnItemSelectedListener(
                new AdapterView.OnItemSelectedListener() {

                    @Override
                    public void onItemSelected(
                            AdapterView<?> parent,
                            View view,
                            int position,
                            long id) {

                        sortItems(position);
                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {
                        // No action needed
                    }
                });

        // Add item button logic
        findViewById(R.id.addBtn).setOnClickListener(v -> {
            try {
                String itemName = name.getText().toString().trim();
                String quantityText = qty.getText().toString().trim();

                if (itemName.isEmpty() || quantityText.isEmpty()) {
                    Toast.makeText(
                            this,
                            "Item name and quantity are required",
                            Toast.LENGTH_SHORT
                    ).show();

                    return;
                }

                int quantity = Integer.parseInt(quantityText);

                if (quantity < 0) {
                    Toast.makeText(
                            this,
                            "Quantity cannot be negative",
                            Toast.LENGTH_SHORT
                    ).show();

                    return;
                }

                db.addItem(itemName, quantity);

                // Refresh while preserving the current search.
                String currentSearch =
                        searchInput.getText().toString().trim();

                if (currentSearch.isEmpty()) {
                    load();
                } else {
                    search(currentSearch);
                }

                // Clear item-entry fields after successful insertion.
                name.setText("");
                qty.setText("");

            } catch (NumberFormatException e) {
                Toast.makeText(
                        this,
                        "Quantity must be a valid number",
                        Toast.LENGTH_SHORT
                ).show();
            }
        });

        // Search inventory as the user types
        searchInput.addTextChangedListener(new TextWatcher() {

            @Override
            public void beforeTextChanged(
                    CharSequence s,
                    int start,
                    int count,
                    int after) {
                // No action needed
            }

            @Override
            public void onTextChanged(
                    CharSequence s,
                    int start,
                    int before,
                    int count) {

                search(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {
                // No action needed
            }
        });

        // Apply or remove the low-stock filter
        lowStockCheckBox.setOnCheckedChangeListener(
                (buttonView, isChecked) -> applyFilters()
        );

        // Request SMS permission
        findViewById(R.id.smsBtn).setOnClickListener(v -> {
            ActivityCompat.requestPermissions(
                    this,
                    new String[]{Manifest.permission.SEND_SMS},
                    1
            );
        });

        // Load inventory when application starts
        load();
    }

    // Load all inventory items from SQLite
    private void load() {
        Cursor cursor = db.getItems();
        loadCursorData(cursor);
    }

    // Search inventory using a targeted SQLite query
    private void search(String searchText) {

        String query = searchText.trim();

        // An empty search displays the entire inventory.
        if (query.isEmpty()) {
            load();
            return;
        }

        Cursor cursor = db.searchItems(query);
        loadCursorData(cursor);
    }

    // Convert database rows into Item objects
    private void loadCursorData(Cursor cursor) {

        allItems.clear();

        try {
            while (cursor.moveToNext()) {

                Item item = new Item(
                        cursor.getInt(0),
                        cursor.getString(1),
                        cursor.getInt(2)
                );

                allItems.add(item);
            }
        } finally {
            cursor.close();
        }

        applyFilters();
    }

    // Filter the source collection using a linear traversal
    private void applyFilters() {

        list.clear();

        boolean lowStockOnly = lowStockCheckBox.isChecked();

        for (Item item : allItems) {

            if (!lowStockOnly ||
                    item.quantity <= LOW_STOCK_THRESHOLD) {

                list.add(item);
            }
        }

        // Preserve the selected sort order after filtering
        sortItems(sortSpinner.getSelectedItemPosition());
    }

    // Sort the displayed collection using the selected comparator
    private void sortItems(int sortOption) {

        switch (sortOption) {

            case 0:
                // Alphabetical A to Z
                Collections.sort(
                        list,
                        (a, b) ->
                                a.name.compareToIgnoreCase(b.name)
                );
                break;

            case 1:
                // Alphabetical Z to A
                Collections.sort(
                        list,
                        (a, b) ->
                                b.name.compareToIgnoreCase(a.name)
                );
                break;

            case 2:
                // Quantity from lowest to highest
                Collections.sort(
                        list,
                        (a, b) ->
                                Integer.compare(
                                        a.quantity,
                                        b.quantity
                                )
                );
                break;

            case 3:
                // Quantity from highest to lowest
                Collections.sort(
                        list,
                        (a, b) ->
                                Integer.compare(
                                        b.quantity,
                                        a.quantity
                                )
                );
                break;
        }

        adapter.notifyDataSetChanged();
    }

    // Handle SMS permission result
    @Override
    public void onRequestPermissionsResult(
            int requestCode,
            String[] permissions,
            int[] grantResults) {

        super.onRequestPermissionsResult(
                requestCode,
                permissions,
                grantResults
        );

        if (requestCode == 1 &&
                grantResults.length > 0 &&
                grantResults[0] == 0) {

            SmsManager.getDefault().sendTextMessage(
                    "1234567890",
                    null,
                    "Inventory Alert",
                    null,
                    null
            );

        } else {

            Toast.makeText(
                    this,
                    "SMS denied",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }
}