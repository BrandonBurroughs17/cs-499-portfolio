package com.example.inventoryapp.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    // Database name and version
    private static final String DB_NAME = "inventory.db";
    private static final int DB_VERSION = 1;

    public DatabaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        // Create user table for login credentials
        db.execSQL("CREATE TABLE users (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "username TEXT UNIQUE," +
                "password TEXT)");

        // Create inventory table for storing items
        db.execSQL("CREATE TABLE items (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "name TEXT," +
                "quantity INTEGER)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Not needed for this project version
    }

    // ---------- USER METHODS ----------

    // Check if a username already exists in the database
    public boolean userExists(String username) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor c = db.rawQuery(
                "SELECT * FROM users WHERE username=?",
                new String[]{username}
        );

        boolean exists = c.getCount() > 0;
        c.close();

        return exists;
    }

    // Validate login credentials
    public boolean validateUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor c = db.rawQuery(
                "SELECT * FROM users WHERE username=? AND password=?",
                new String[]{username, password}
        );

        boolean valid = c.getCount() > 0;
        c.close();

        return valid;
    }

    // Insert new user into database
    public void insertUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("username", username);
        values.put("password", password);

        db.insert("users", null, values);
    }

    // ---------- ITEM METHODS ----------

    // Add a new inventory item
    public void addItem(String name, int qty) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("name", name);
        values.put("quantity", qty);

        db.insert("items", null, values);
    }

    // Retrieve all inventory items
    public Cursor getItems() {
        SQLiteDatabase db = this.getReadableDatabase();

        return db.rawQuery(
                "SELECT * FROM items",
                null
        );
    }

    // Search inventory items by name and return matches alphabetically
    public Cursor searchItems(String searchText) {
        SQLiteDatabase db = this.getReadableDatabase();

        String query =
                "SELECT * FROM items " +
                        "WHERE name LIKE ?";

        String[] args = {
                "%" + searchText + "%"
        };

        return db.rawQuery(query, args);
    }
}