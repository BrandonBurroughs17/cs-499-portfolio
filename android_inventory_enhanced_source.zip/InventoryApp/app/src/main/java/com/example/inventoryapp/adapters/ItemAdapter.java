package com.example.inventoryapp.adapters;

import android.view.*;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

import com.example.inventoryapp.models.Item;
import com.example.inventoryapp.R;

public class ItemAdapter extends RecyclerView.Adapter<ItemAdapter.ViewHolder> {

    List<Item> items;

    public ItemAdapter(List<Item> items) {
        this.items = items;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView name, qty;

        public ViewHolder(View v) {
            super(v);
            name = v.findViewById(R.id.itemName);
            qty = v.findViewById(R.id.itemQty);
        }
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_row, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(ViewHolder h, int pos) {
        Item i = items.get(pos);
        h.name.setText(i.name);
        h.qty.setText(String.valueOf(i.quantity));
    }

    @Override
    public int getItemCount() {
        return items.size();
    }
}