import os

os.environ["MONGO_COLLECTION"] = "animals_capstone_test"

from AnimalShelter import AnimalShelter


db = AnimalShelter()

print("----- INVALID CREATE -----")
print("Result:", db.create(None))

print("\n----- INVALID READ -----")
print("Result:", db.read("not a dictionary"))

print("\n----- UNSAFE UPDATE -----")
print(
    "Result:",
    db.update(
        {},
        {"$set": {"name": "Unsafe Update"}}
    )
)

print("\n----- INVALID UPDATE OPERATOR -----")
print(
    "Result:",
    db.update(
        {"name": "Test"},
        {"name": "No MongoDB Operator"}
    )
)

print("\n----- UNSAFE DELETE -----")
print("Result:", db.delete({}))

db.close()