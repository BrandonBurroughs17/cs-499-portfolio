from AnimalShelter import AnimalShelter


db = AnimalShelter()

water_query = {
    "breed": {"$regex": "Labrador|Chesapeake"},
    "age_upon_outcome_in_weeks": {"$lt": 104}
}

mountain_query = {
    "breed": {"$regex": "German Shepherd|Malamute"},
    "age_upon_outcome_in_weeks": {"$lt": 104}
}

disaster_query = {
    "breed": {"$regex": "Bloodhound|Rottweiler"},
    "age_upon_outcome_in_weeks": {"$lt": 104}
}


print("----- DATABASE -----")
print("Total animals:", db.collection.count_documents({}))

print("\n----- RESCUE FILTERS -----")
print(
    "Water Rescue:",
    db.collection.count_documents(water_query)
)

print(
    "Mountain Rescue:",
    db.collection.count_documents(mountain_query)
)

print(
    "Disaster Rescue:",
    db.collection.count_documents(disaster_query)
)

print("\n----- SAMPLE RECORD -----")

sample = db.collection.find_one(
    {"breed": {"$regex": "Labrador"}},
    {
        "_id": 0,
        "breed": 1,
        "age_upon_outcome_in_weeks": 1,
        "location_lat": 1,
        "location_long": 1
    }
)

print(sample)

if sample:
    age = sample.get("age_upon_outcome_in_weeks")

    print(
        "Age value:",
        age
    )

    print(
        "Python age type:",
        type(age).__name__
    )

db.close()