import os

from pymongo import ASCENDING, MongoClient
from pymongo.errors import PyMongoError


class AnimalShelter:
    """CRUD operations for the Animal collection in MongoDB."""

    def __init__(self):
        # Load database configuration from environment variables.
        host = os.getenv("MONGO_HOST", "localhost")
        port = int(os.getenv("MONGO_PORT", "27017"))
        database_name = os.getenv("MONGO_DB", "aac")
        collection_name = os.getenv("MONGO_COLLECTION", "animals")

        username = os.getenv("MONGO_USERNAME")
        password = os.getenv("MONGO_PASSWORD")

        # Use authentication only when credentials are supplied.
        if username and password:
            self.client = MongoClient(
                host=host,
                port=port,
                username=username,
                password=password,
                serverSelectionTimeoutMS=5000
            )
        else:
            self.client = MongoClient(
                host=host,
                port=port,
                serverSelectionTimeoutMS=5000
            )

        self.database = self.client[database_name]
        self.collection = self.database[collection_name]

        # Verify that MongoDB is reachable.
        self._validate_connection()

    def _validate_connection(self):
        """Verify that the MongoDB server is reachable."""

        try:
            self.client.admin.command("ping")

        except PyMongoError as error:
            self.client.close()

            raise ConnectionError(
                f"Unable to connect to MongoDB: {error}"
            ) from error

    # CREATE
    def create(self, data):
        """Insert one animal document into the collection."""

        if not isinstance(data, dict) or not data:
            print(
                "Create Error: data must be a non-empty dictionary."
            )
            return False

        try:
            result = self.collection.insert_one(data)
            return result.acknowledged

        except PyMongoError as error:
            print(f"Create Database Error: {error}")
            return False

    # READ
    def read(self, query):
        """Return animal documents matching a MongoDB query."""

        if not isinstance(query, dict):
            print(
                "Read Error: query must be a dictionary."
            )
            return []

        try:
            return list(self.collection.find(query))

        except PyMongoError as error:
            print(f"Read Database Error: {error}")
            return []

    # UPDATE
    def update(self, query, new_values):
        """Update animal documents matching the supplied query."""

        if not isinstance(query, dict) or not query:
            print(
                "Update Error: query must be a non-empty dictionary."
            )
            return 0

        if not isinstance(new_values, dict) or not new_values:
            print(
                "Update Error: update values must be "
                "a non-empty dictionary."
            )
            return 0

        # Require a MongoDB update operator such as $set.
        if not any(
            key.startswith("$") for key in new_values
        ):
            print(
                "Update Error: update values must use "
                "a MongoDB update operator."
            )
            return 0

        try:
            result = self.collection.update_many(
                query,
                new_values
            )

            return result.modified_count

        except PyMongoError as error:
            print(f"Update Database Error: {error}")
            return 0

    # DELETE
    def delete(self, query):
        """Delete animal documents matching the supplied query."""

        if not isinstance(query, dict) or not query:
            print(
                "Delete Error: query must be a non-empty dictionary."
            )
            return 0

        try:
            result = self.collection.delete_many(query)
            return result.deleted_count

        except PyMongoError as error:
            print(f"Delete Database Error: {error}")
            return 0

    # INDEX MANAGEMENT
    def create_indexes(self):
        """Create indexes used by the dashboard rescue queries."""

        try:
            index_name = self.collection.create_index(
                [
                    ("age_upon_outcome_in_weeks", ASCENDING),
                    ("breed", ASCENDING)
                ],
                name="rescue_filter_idx"
            )

            return index_name

        except PyMongoError as error:
            print(f"Index Creation Error: {error}")
            return None

    def get_indexes(self):
        """Return information about indexes on the animal collection."""

        try:
            return list(self.collection.list_indexes())

        except PyMongoError as error:
            print(f"Index Read Error: {error}")
            return []

    def close(self):
        """Close the MongoDB client connection."""

        self.client.close()