"""
Compatibility module for the Grazioso Salvare application.

The primary AnimalShelter CRUD implementation is maintained in
AnimalShelter.py. This module preserves compatibility with code that
imports AnimalShelter from the original CRUD_Python_Module.
"""

from AnimalShelter import AnimalShelter

__all__ = ["AnimalShelter"]