import os

# Use a separate collection for testing.
os.environ["MONGO_COLLECTION"] = "animals_capstone_test"

from AnimalShelter import AnimalShelter


db = AnimalShelter()

test_animal = {
    "name": "CS499 Test Animal",
    "breed": "Labrador Retriever",
    "age_upon_outcome_in_weeks": 52,
    "capstone_test": True
}

print("----- CREATE TEST -----")
created = db.create(test_animal)
print("Created:", created)

print("\n----- READ TEST -----")
records = db.read({"capstone_test": True})
print("Records found:", len(records))

if records:
    print("Animal name:", records[0].get("name"))
    print(
        "Animal age:",
        records[0].get("age_upon_outcome_in_weeks")
    )

print("\n----- UPDATE TEST -----")
updated = db.update(
    {"capstone_test": True},
    {"$set": {"age_upon_outcome_in_weeks": 60}}
)
print("Records updated:", updated)

records = db.read({"capstone_test": True})

if records:
    print(
        "Updated age:",
        records[0].get("age_upon_outcome_in_weeks")
    )

print("\n----- DELETE TEST -----")
deleted = db.delete({"capstone_test": True})
print("Records deleted:", deleted)

remaining = db.read({"capstone_test": True})
print("Records remaining:", len(remaining))

db.close()