import pandas as pd

from AnimalShelter import AnimalShelter


CSV_FILE = "aac_shelter_outcomes.csv"


print("Reading CSV...")

df = pd.read_csv(CSV_FILE)

# Remove CSV-generated index columns that are not animal data.
df = df.loc[:, ~df.columns.str.startswith("Unnamed:")]

# Convert pandas NaN values to None so MongoDB stores
# missing values cleanly.
df = df.where(pd.notnull(df), None)

records = df.to_dict("records")

print(f"Records loaded from CSV: {len(records)}")


db = AnimalShelter()

existing_count = db.collection.count_documents({})

print(f"Existing MongoDB documents: {existing_count}")

if existing_count > 0:
    print(
        "Import stopped because the animals collection "
        "already contains data."
    )
else:
    result = db.collection.insert_many(records)

    print(f"Documents inserted: {len(result.inserted_ids)}")
    print(
        "Documents now in MongoDB:",
        db.collection.count_documents({})
    )

db.close()