# Grazioso Salvare Rescue Animal Dashboard

## CS 499 Database Enhancement

This project is an enhanced version of the Grazioso Salvare rescue animal
dashboard originally created for CS 340: Client/Server Development.

The application uses Python, MongoDB, Pandas, Plotly Dash, and Dash Leaflet
to display and filter animal shelter data for different rescue categories.

## Enhancements

The database and application layers were updated to improve security,
maintainability, reliability, and compatibility.

Enhancements include:

- Removed hard-coded MongoDB credentials from the application.
- Added environment-variable-based MongoDB configuration.
- Added MongoDB connection validation using a ping operation.
- Added a connection timeout to prevent indefinite connection attempts.
- Added input validation to CRUD operations.
- Added safeguards against unrestricted update and delete operations.
- Added validation for MongoDB update operators.
- Replaced broad exception handling with PyMongo-specific error handling.
- Added MongoDB index creation and inspection functionality.
- Consolidated duplicate CRUD implementations into one maintained
  AnimalShelter class.
- Added explicit MongoDB connection cleanup.
- Updated the dashboard from the deprecated JupyterDash implementation
  to the current Dash implementation.
- Replaced map column-number references with named database fields.
- Removed the unnecessary CSV-generated "Unnamed: 0" field.
- Added scripts for CRUD, validation, and rescue-query testing.

## Requirements

Install the project dependencies with:

    pip install -r requirements.txt

MongoDB must also be installed and running.

## MongoDB Configuration

The application supports the following environment variables:

- MONGO_HOST
- MONGO_PORT
- MONGO_DB
- MONGO_COLLECTION
- MONGO_USERNAME
- MONGO_PASSWORD

Default local configuration:

    MONGO_HOST=localhost
    MONGO_PORT=27017
    MONGO_DB=aac
    MONGO_COLLECTION=animals

MongoDB credentials are not stored in the source code. If authentication is
required, provide MONGO_USERNAME and MONGO_PASSWORD through the environment.

## Importing the Dataset

The included `aac_shelter_outcomes.csv` file contains the animal shelter
dataset used by the dashboard.

Import the dataset with:

    python import_data.py

The import script prevents duplicate imports when the animals collection
already contains data.

## Running Tests

CRUD operations:

    python test_CRUD.py

Input and destructive-operation validation:

    python test_validation.py

Rescue queries:

    python test_rescue_queries.py

The rescue-query test verifies the Water Rescue, Mountain/Wilderness Rescue,
and Disaster/Tracking database queries against the MongoDB collection.

## Running the Dashboard

Start the Jupyter notebook with:

    jupyter notebook ProjectTwoDashboard.ipynb

Run the dashboard cell and open the local Dash address displayed by the
notebook.

The dashboard provides:

- All animal records
- Water Rescue filtering
- Mountain/Wilderness Rescue filtering
- Disaster/Tracking filtering
- Top animal breed visualization
- Interactive animal location mapping

## Security

Sensitive database credentials are externalized from the source code.
Database operations validate incoming arguments, and update and delete
operations reject empty queries to reduce the risk of unintended bulk
modification or deletion.