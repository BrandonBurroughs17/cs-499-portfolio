from AnimalShelter import AnimalShelter


db = AnimalShelter()

query = {
    "Unnamed: 0": {"$exists": True}
}

update = {
    "$unset": {"Unnamed: 0": ""}
}

modified = db.update(query, update)

print("Documents cleaned:", modified)

remaining = db.collection.count_documents(
    {"Unnamed: 0": {"$exists": True}}
)

print("Documents still containing Unnamed: 0:", remaining)

db.close()