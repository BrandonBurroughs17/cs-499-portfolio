package com.example.inventoryapp.activities;

import android.content.Intent;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

import com.example.inventoryapp.database.DatabaseHelper;
import com.example.inventoryapp.R;

public class LoginActivity extends AppCompatActivity {

    EditText user, pass;
    Button loginBtn;
    DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize database helper
        db = new DatabaseHelper(this);

        // Link UI components
        user = findViewById(R.id.username);
        pass = findViewById(R.id.password);
        loginBtn = findViewById(R.id.loginBtn);

        // Handle login button click
        loginBtn.setOnClickListener(v -> {

            String u = user.getText().toString();
            String p = pass.getText().toString();

            // If user exists, validate password
            if (db.userExists(u)) {
                if (db.validateUser(u, p)) {
                    startActivity(new Intent(this, MainActivity.class));
                } else {
                    Toast.makeText(this, "Wrong password", Toast.LENGTH_SHORT).show();
                }
            }
            // If user does not exist, create new account
            else {
                db.insertUser(u, p);
                Toast.makeText(this, "Account created", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(this, MainActivity.class));
            }
        });
    }
}
