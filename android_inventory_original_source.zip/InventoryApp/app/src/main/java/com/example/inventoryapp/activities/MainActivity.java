package com.example.inventoryapp.activities;

import android.Manifest;
import android.database.Cursor;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.*;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.*;

import java.util.*;

import com.example.inventoryapp.database.DatabaseHelper;
import com.example.inventoryapp.models.Item;
import com.example.inventoryapp.adapters.ItemAdapter;
import com.example.inventoryapp.R;

public class MainActivity extends AppCompatActivity {

    DatabaseHelper db;                // Database instance
    List<Item> list = new ArrayList<>(); // Holds items for RecyclerView
    ItemAdapter adapter;

    EditText name, qty;
    RecyclerView rv;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_inventory);

        // Initialize database
        db = new DatabaseHelper(this);

        // Link UI elements
        name = findViewById(R.id.nameInput);
        qty = findViewById(R.id.qtyInput);
        rv = findViewById(R.id.recyclerView);

        // Setup RecyclerView
        rv.setLayoutManager(new LinearLayoutManager(this));
        adapter = new ItemAdapter(list);
        rv.setAdapter(adapter);

        // Add item button logic
        findViewById(R.id.addBtn).setOnClickListener(v -> {
            try {
                db.addItem(
                        name.getText().toString(),
                        Integer.parseInt(qty.getText().toString())
                );
                load(); // Refresh list after insert
            } catch (Exception e) {
                // Handles invalid number input
                Toast.makeText(this, "Invalid input", Toast.LENGTH_SHORT).show();
            }
        });

        // Request SMS permission
        findViewById(R.id.smsBtn).setOnClickListener(v -> {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.SEND_SMS}, 1);
        });

        load(); // Load data on startup
    }

    // Load items from database into RecyclerView
    private void load() {
        list.clear();
        Cursor c = db.getItems();

        while (c.moveToNext()) {
            list.add(new Item(
                    c.getInt(0),
                    c.getString(1),
                    c.getInt(2)
            ));
        }

        adapter.notifyDataSetChanged();
    }

    // Handle SMS permission result
    @Override
    public void onRequestPermissionsResult(int r, String[] p, int[] g) {
        if (r == 1 && g.length > 0 && g[0] == 0) {
            // Permission granted → send SMS
            SmsManager.getDefault().sendTextMessage(
                    "1234567890", null,
                    "Inventory Alert", null, null);
        } else {
            // Permission denied → app still functions
            Toast.makeText(this, "SMS denied", Toast.LENGTH_SHORT).show();
        }
    }
}