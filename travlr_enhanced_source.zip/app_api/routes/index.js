const express = require('express');

const router = express.Router();

const ctrlTrips = require('../controllers/trips');
const ctrlAuth = require('../controllers/authentication');
const authenticateToken = require('../middleware/auth');

router
    .route('/trips')
    .get(ctrlTrips.tripsList)
    .post(authenticateToken, ctrlTrips.tripsAddTrip);

router
    .route('/trips/:tripCode')
    .get(ctrlTrips.tripsFindByCode)
    .put(authenticateToken, ctrlTrips.tripsUpdateTrip)
    .delete(authenticateToken, ctrlTrips.tripsDeleteTrip);

router
    .route('/login')
    .post(ctrlAuth.login);

module.exports = router;