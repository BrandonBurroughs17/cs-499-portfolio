const mongoose = require('mongoose');
const Trip = mongoose.model('trips');

// Fields that clients are allowed to create or update.
const allowedTripFields = [
    'code',
    'name',
    'length',
    'start',
    'resort',
    'perPerson',
    'image',
    'description'
];

// Validate required trip data before sending it to MongoDB.
const validateTrip = (data) => {
    const missingFields = allowedTripFields.filter((field) => {
        return data[field] === undefined ||
               data[field] === null ||
               data[field] === '';
    });

    if (missingFields.length > 0) {
        return `Missing required fields: ${missingFields.join(', ')}`;
    }

    const startDate = new Date(data.start);

    if (Number.isNaN(startDate.getTime())) {
        return 'Start date must be a valid date';
    }

    return null;
};

// Only copy fields that the API explicitly allows.
const getTripData = (data) => ({
    code: data.code,
    name: data.name,
    length: data.length,
    start: data.start,
    resort: data.resort,
    perPerson: data.perPerson,
    image: data.image,
    description: data.description
});

const tripsList = async (req, res) => {
    try {
        const trips = await Trip.find();

        return res.status(200).json(trips);
    } catch (error) {
        console.error('Error retrieving trips:', error);

        return res.status(500).json({
            message: 'Unable to retrieve trips'
        });
    }
};

const tripsFindByCode = async (req, res) => {
    try {
        const trip = await Trip.findOne({
            code: req.params.tripCode
        });

        if (!trip) {
            return res.status(404).json({
                message: 'Trip not found'
            });
        }

        return res.status(200).json(trip);
    } catch (error) {
        console.error('Error retrieving trip:', error);

        return res.status(500).json({
            message: 'Unable to retrieve trip'
        });
    }
};

const tripsAddTrip = async (req, res) => {
    try {
        const validationError = validateTrip(req.body);

        if (validationError) {
            return res.status(400).json({
                message: validationError
            });
        }

        const tripData = getTripData(req.body);

        const trip = await Trip.create(tripData);

        return res.status(201).json(trip);
    } catch (error) {
        console.error('Error creating trip:', error);

        return res.status(500).json({
            message: 'Unable to create trip'
        });
    }
};

const tripsUpdateTrip = async (req, res) => {
    try {
        const trip = await Trip.findOne({
            code: req.params.tripCode
        });

        if (!trip) {
            return res.status(404).json({
                message: 'Trip not found'
            });
        }

        const validationError = validateTrip(req.body);

        if (validationError) {
            return res.status(400).json({
                message: validationError
            });
        }

        const tripData = getTripData(req.body);

        allowedTripFields.forEach((field) => {
            trip[field] = tripData[field];
        });

        const updatedTrip = await trip.save();

        return res.status(200).json(updatedTrip);
    } catch (error) {
        console.error('Error updating trip:', error);

        return res.status(500).json({
            message: 'Unable to update trip'
        });
    }
};

const tripsDeleteTrip = async (req, res) => {
    try {
        const result = await Trip.deleteOne({
            code: req.params.tripCode
        });

        if (result.deletedCount === 0) {
            return res.status(404).json({
                message: 'Trip not found'
            });
        }

        return res.status(204).send();
    } catch (error) {
        console.error('Error deleting trip:', error);

        return res.status(500).json({
            message: 'Unable to delete trip'
        });
    }
};

module.exports = {
    tripsList,
    tripsFindByCode,
    tripsAddTrip,
    tripsUpdateTrip,
    tripsDeleteTrip
};