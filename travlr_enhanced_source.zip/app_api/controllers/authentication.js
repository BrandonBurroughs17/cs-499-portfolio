const mongoose = require('mongoose');
const jwt = require('jsonwebtoken');

const User = mongoose.model('users');

const login = async (req, res) => {
    try {
        const { email, password } = req.body;

        // Validate required login fields.
        if (!email || !password) {
            return res.status(400).json({
                message: 'Email and password are required'
            });
        }

        // Find the user by email.
        const user = await User.findOne({
            email: email.trim().toLowerCase()
        });

        // Use the same response for an unknown user or invalid password.
        if (!user) {
            return res.status(401).json({
                message: 'Invalid credentials'
            });
        }

        const validPassword = await user.validatePassword(password);

        if (!validPassword) {
            return res.status(401).json({
                message: 'Invalid credentials'
            });
        }

        // Ensure the JWT signing secret has been configured.
        if (!process.env.JWT_SECRET) {
            console.error('JWT_SECRET is not configured');

            return res.status(500).json({
                message: 'Authentication service is unavailable'
            });
        }

        const token = jwt.sign(
            {
                userId: user._id,
                email: user.email
            },
            process.env.JWT_SECRET,
            {
                expiresIn: '1h'
            }
        );

        return res.status(200).json({
            token
        });
    } catch (error) {
        console.error('Login error:', error);

        return res.status(500).json({
            message: 'An internal server error occurred'
        });
    }
};

module.exports = {
    login
};