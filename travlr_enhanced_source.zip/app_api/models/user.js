const mongoose = require('mongoose');
const bcrypt = require('bcrypt');

const userSchema = new mongoose.Schema({
    email: {
        type: String,
        required: true,
        unique: true,
        trim: true,
        lowercase: true
    },
    password: {
        type: String,
        required: true
    },
    name: {
        type: String,
        required: true,
        trim: true
    }
});

// Hash the password before saving a new or modified password.
userSchema.pre('save', async function () {
    if (!this.isModified('password')) {
        return;
    }

    const saltRounds = 12;
    this.password = await bcrypt.hash(this.password, saltRounds);
});

// Compare a submitted password with the stored password hash.
userSchema.methods.validatePassword = async function (password) {
    return bcrypt.compare(password, this.password);
};

mongoose.model('users', userSchema);