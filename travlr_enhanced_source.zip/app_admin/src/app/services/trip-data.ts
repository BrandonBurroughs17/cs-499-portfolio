import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Trip } from '../models/trip';

@Injectable({
  providedIn: 'root'
})
export class TripDataService {

  private http = inject(HttpClient);

  private apiUrl = 'http://localhost:3000/api/trips';

  private getAuthHeaders() {
    const token = localStorage.getItem('travlr-token') || '';

    return {
      headers: new HttpHeaders({
        Authorization: `Bearer ${token}`
      })
    };
  }

  getTrips() {
    return this.http.get<Trip[]>(
      this.apiUrl,
      this.getAuthHeaders()
    );
  }

  getTrip(tripCode: string) {
    return this.http.get<Trip>(
      `${this.apiUrl}/${tripCode}`,
      this.getAuthHeaders()
    );
  }

  addTrip(trip: Trip) {
    return this.http.post<Trip>(
      this.apiUrl,
      trip,
      this.getAuthHeaders()
    );
  }

  updateTrip(tripCode: string, trip: Trip) {
    return this.http.put<Trip>(
      `${this.apiUrl}/${tripCode}`,
      trip,
      this.getAuthHeaders()
    );
  }

  deleteTrip(tripCode: string) {
    return this.http.delete<void>(
      `${this.apiUrl}/${tripCode}`,
      this.getAuthHeaders()
    );
  }

}