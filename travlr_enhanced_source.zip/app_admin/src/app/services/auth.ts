import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';

export interface LoginCredentials {
  email: string;
  password: string;
}

export interface AuthResponse {
  token: string;
}

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  private http = inject(HttpClient);

  login(credentials: LoginCredentials) {
    return this.http.post<AuthResponse>(
      'http://localhost:3000/api/login',
      credentials
    );
  }

}