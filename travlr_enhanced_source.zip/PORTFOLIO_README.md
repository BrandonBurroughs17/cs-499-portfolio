# Travlr Getaways | CS 499 Enhancement One

This is the source code for the Software Design and Engineering capstone enhancement.

The public portfolio copy omits local `.env` files, installed `node_modules`, Angular caches, and generated build output. Dependencies are declared in the package manifests and can be reinstalled with `npm install` (root project and `app_admin`).

**Public sharing adjustment:** `seedAdmin.js` was updated to read `ADMIN_SEED_PASSWORD` and optional `ADMIN_SEED_EMAIL` from local environment variables instead of shipping a hard-coded demonstration password. This is a security cleanup for the public copy. The original Milestone Two submission is unchanged.

Copy `.env.example` to `.env` locally, set a strong `JWT_SECRET` and `ADMIN_SEED_PASSWORD`, and keep `.env` out of version control. A local MongoDB instance is required to run the app.

The original CS 465 source is separately available as `travlr_original_source.zip` in the portfolio. Its hard-coded demo login and signing secret are included to document the weaknesses addressed by this enhancement; do not deploy the original project.
