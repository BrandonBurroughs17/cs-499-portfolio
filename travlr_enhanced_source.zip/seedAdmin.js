require('dotenv').config();

const mongoose = require('mongoose');
require('./app_api/models/user');

const User = mongoose.model('users');

const seedAdmin = async () => {
    const password = process.env.ADMIN_SEED_PASSWORD;
    const email = (process.env.ADMIN_SEED_EMAIL || 'admin@test.com').trim().toLowerCase();

    if (!password || password.length < 12) {
        console.error('Set ADMIN_SEED_PASSWORD in your local .env (at least 12 characters) before seeding.');
        process.exitCode = 1;
        return;
    }

    try {
        await mongoose.connect('mongodb://127.0.0.1:27017/travlr');
        const existingUser = await User.findOne({ email });
        if (existingUser) {
            console.log('Admin user already exists.');
            return;
        }
        await User.create({
            name: 'Travlr Administrator',
            email,
            password
        });
        console.log('Admin user created successfully.');
    } catch (error) {
        console.error('Unable to create admin user:', error);
        process.exitCode = 1;
    } finally {
        await mongoose.connection.close();
    }
};

seedAdmin();
